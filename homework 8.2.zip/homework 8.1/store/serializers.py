from rest_framework import serializers

from .models import Book, Genre


class BookSerializer(serializers.Serializer):
    id = serializers.BigIntegerField(read_only=True)
    title = serializers.CharField(max_length=255)
    author = serializers.CharField(max_length=255, default="none")
    price = serializers.IntegerField(default=0)
    genre_id = serializers.IntegerField(required=False, allow_null=True)

    def create(self, validated_data):
        return Book.objects.create(**validated_data)

    def update(self, instance: Book, validated_data):
        instance.title = validated_data.get("title", instance.title)
        instance.author = validated_data.get("author", instance.author)
        instance.price = validated_data.get("price", instance.price)
        instance.genre_id = validated_data.get("genre_id", instance.genre_id)

        instance.save()

        return instance


class GenreSerializer(serializers.Serializer):
    id = serializers.BigIntegerField(read_only=True)
    name = serializers.CharField(max_length=255)

    def create(self, validated_data):
        return Genre.objects.create(**validated_data)

    def update(self, instance: Genre, validated_data):
        instance.name = validated_data.get("name", instance.name)

        instance.save()

        return instance