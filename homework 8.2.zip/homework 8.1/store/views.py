#
# from django.forms import model_to_dict
# from rest_framework.views import APIView
# from rest_framework.request import Request
# from rest_framework.response import Response
# from .models import Book, Genre
#
#
#
# class BookAPIView(APIView):
#     def get(self, request: Request):
#         books = Book.objects.all()
#         books_list = []
#
#         for book in books:
#             books_list.append(
#                 {
#                     "id": book.id,
#                     "title": book.title,
#                     "author": book.author,
#                     "price": book.price,
#                     "genre_id": book.genre.id,
#                 }
#             )
#
#         return Response(books_list)
#
#     def post(self, request):
#         book = Book.objects.create(**request.data)
#         book_dict = model_to_dict(book)
#         return Response(book_dict, status=201)
#
#
# class GenreAPIView(APIView):
#     def get(self, request: Request):
#         genres = Genre.objects.all()
#         genres_list = []
#
#         for genre in genres:
#             genres_list.append(
#                 {
#                     "id": genre.id,
#                     "name": genre.name,
#
#                 }
#             )
#
#         return Response(genres_list)
#
#     def post(self, request):
#         genre = Genre.objects.create(**request.data)
#         genre_dict = model_to_dict(genre)
#         return Response(genre_dict, status=201)
#


from rest_framework.generics import get_object_or_404
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status

from .models import Book, Genre
from .serializers import BookSerializer, GenreSerializer


class BookAPIView(APIView):

    def get(self, request: Request, pk: int = None):
        if pk is None:
            books = Book.objects.all()
            serializer = BookSerializer(books, many=True)

            return Response(serializer.data)

        else:
            book = get_object_or_404(Book, pk=pk)

            return Response(
                BookSerializer(book).data
            )

    def post(self, request, pk: int = None):
        if pk:
            return Response(
                {"message": "Method POST not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        serializer = BookSerializer(data=request.data)

        serializer.is_valid(raise_exception=True)

        book = serializer.save()

        return Response(
            BookSerializer(book).data,
            status=status.HTTP_201_CREATED
        )

    def put(self, request, pk: int = None):
        if not pk:
            return Response(
                {"message": "Method PUT not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        book = get_object_or_404(Book, pk=pk)

        serializer = BookSerializer(
            data=request.data,
            instance=book
        )

        serializer.is_valid(raise_exception=True)

        return Response(
            BookSerializer(serializer.save()).data
        )

    def delete(self, request, pk: int = None):
        if not pk:
            return Response(
                {"message": "Method DELETE not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        book = get_object_or_404(Book, pk=pk)

        book.delete()

        return Response(
            {"message": "Book deleted successful"},
            status=status.HTTP_204_NO_CONTENT
        )


class GenreAPIView(APIView):

    def get(self, request: Request, pk: int = None):
        if pk is None:
            genres = Genre.objects.all()
            serializer = GenreSerializer(genres, many=True)

            return Response(serializer.data)

        else:
            genre = get_object_or_404(Genre, pk=pk)

            return Response(
                GenreSerializer(genre).data
            )

    def post(self, request, pk: int = None):
        if pk:
            return Response(
                {"message": "Method POST not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        serializer = GenreSerializer(data=request.data)

        serializer.is_valid(raise_exception=True)

        genre = serializer.save()

        return Response(
            GenreSerializer(genre).data,
            status=status.HTTP_201_CREATED
        )

    def put(self, request, pk: int = None):
        if not pk:
            return Response(
                {"message": "Method PUT not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        genre = get_object_or_404(Genre, pk=pk)

        serializer = GenreSerializer(
            data=request.data,
            instance=genre
        )

        serializer.is_valid(raise_exception=True)

        return Response(
            GenreSerializer(serializer.save()).data
        )

    def delete(self, request, pk: int = None):
        if not pk:
            return Response(
                {"message": "Method DELETE not allowed!"},
                status=status.HTTP_405_METHOD_NOT_ALLOWED
            )

        genre = get_object_or_404(Genre, pk=pk)

        genre.delete()

        return Response(
            {"message": "Genre deleted successful"},
            status=status.HTTP_204_NO_CONTENT
        )